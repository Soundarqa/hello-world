# AI Test Case Copilot

Streamlit-based app that generates structured test cases from Jira user stories (.docx).

## Setup
```bash
pip install -r requirements.txt
export OPENAI_API_KEY="your_api_key_here"
streamlit run main.py
```

## Features
- Upload .docx story
- Auto-extract story text and AC
- Generate test cases (JSON & Excel download)
