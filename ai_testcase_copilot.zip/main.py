import streamlit as st
from docx import Document
import json, io
import pandas as pd
from openai import OpenAI
import os
import re

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = "gpt-4o-mini"
client = OpenAI(api_key=OPENAI_API_KEY)

def read_user_story_from_docx(file_like):
    doc = Document(file_like)
    paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    full_text = "\n".join(paragraphs)
    return full_text

def extract_acceptance_criteria(full_text):
    pattern = re.compile(r"(Acceptance Criteria[:\s]*\n?)(.*)", re.IGNORECASE | re.DOTALL)
    m = pattern.search(full_text)
    if m:
        return m.group(2).strip()
    lines = full_text.splitlines()
    return "\n".join(lines[-10:])

def generate_test_cases_from_story(story_text, desired_count=8):
    acceptance = extract_acceptance_criteria(story_text)
    prompt = f"""
    You are a senior QA engineer. Convert the following Jira user story and acceptance criteria into a list of detailed test cases.

    User story (raw):
    \"\"\"{story_text}\"\"\"

    Acceptance Criteria (extracted):
    \"\"\"{acceptance}\"\"\"

    Return output as strictly valid JSON: an array of objects. Each object should have:
    - id
    - title
    - preconditions
    - steps
    - expected_result
    - priority
    - type

    Provide approximately {desired_count} test cases with positive, negative, and boundary tests.
    Do NOT include any commentary outside the JSON.
    """
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=1200
    )
    text = resp.choices[0].message.content
    try:
        first = text.find("[")
        last = text.rfind("]") + 1
        json_text = text[first:last]
        data = json.loads(json_text)
        return data
    except Exception as e:
        raise ValueError(f"Failed to parse JSON from model. Raw response:\n{text}\nError: {e}")

def testcases_to_excel_bytes(testcases):
    df = pd.json_normalize(testcases)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        df.to_excel(writer, index=False, sheet_name="TestCases")
    return output.getvalue()

st.set_page_config(page_title="AI QA Copilot", page_icon="🤖")
st.title("🤖 AI Copilot — User Story → Test Cases")
st.markdown("Upload a Word document (.docx) containing one user story.")

uploaded_file = st.file_uploader("Upload .docx", type=["docx"])
count = st.slider("Approx. number of test cases", 4, 20, 8)

if uploaded_file:
    try:
        story_text = read_user_story_from_docx(uploaded_file)
        st.subheader("Extracted Story Text")
        st.text_area("Story", story_text, height=250)

        if st.button("Generate Test Cases"):
            if not OPENAI_API_KEY:
                st.error("OPENAI_API_KEY not set in environment.")
            else:
                with st.spinner("Generating test cases..."):
                    try:
                        testcases = generate_test_cases_from_story(story_text, count)
                        st.success(f"Generated {len(testcases)} test cases")
                        st.json(testcases)
                        st.download_button("Download JSON", json.dumps(testcases, indent=2),
                                           file_name="testcases.json", mime="application/json")
                        excel_bytes = testcases_to_excel_bytes(testcases)
                        st.download_button("Download Excel", excel_bytes,
                                           file_name="testcases.xlsx",
                                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    except Exception as e:
                        st.error(f"Error generating test cases: {e}")
    except Exception as ex:
        st.error(f"Failed to read file: {ex}")
